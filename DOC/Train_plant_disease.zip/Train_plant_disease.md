# Importing Libraries


```python
!pip install matplotlib
!pip install tensorflow
!pip install pandas
!pip install seaborn
```

    Requirement already satisfied: matplotlib in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (3.8.3)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (4.50.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (1.4.5)
    Requirement already satisfied: numpy<2,>=1.21 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (1.26.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (24.0)
    Requirement already satisfied: pillow>=8 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (10.2.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib) (2.9.0.post0)
    Requirement already satisfied: six>=1.5 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    Requirement already satisfied: tensorflow in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (2.16.1)
    Requirement already satisfied: tensorflow-intel==2.16.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow) (2.16.1)
    Requirement already satisfied: absl-py>=1.0.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.1.0)
    Requirement already satisfied: astunparse>=1.6.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.6.3)
    Requirement already satisfied: flatbuffers>=23.5.26 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (24.3.25)
    Requirement already satisfied: gast!=0.5.0,!=0.5.1,!=0.5.2,>=0.2.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (0.5.4)
    Requirement already satisfied: google-pasta>=0.1.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (0.2.0)
    Requirement already satisfied: h5py>=3.10.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (3.10.0)
    Requirement already satisfied: libclang>=13.0.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (18.1.1)
    Requirement already satisfied: ml-dtypes~=0.3.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (0.3.2)
    Requirement already satisfied: opt-einsum>=2.3.2 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (3.3.0)
    Requirement already satisfied: packaging in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (24.0)
    Requirement already satisfied: protobuf!=4.21.0,!=4.21.1,!=4.21.2,!=4.21.3,!=4.21.4,!=4.21.5,<5.0.0dev,>=3.20.3 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (4.25.3)
    Requirement already satisfied: requests<3,>=2.21.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.31.0)
    Requirement already satisfied: setuptools in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (63.2.0)
    Requirement already satisfied: six>=1.12.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.16.0)
    Requirement already satisfied: termcolor>=1.1.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.4.0)
    Requirement already satisfied: typing-extensions>=3.6.6 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (4.10.0)
    Requirement already satisfied: wrapt>=1.11.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.16.0)
    Requirement already satisfied: grpcio<2.0,>=1.24.3 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.62.1)
    Requirement already satisfied: tensorboard<2.17,>=2.16 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.16.2)
    Requirement already satisfied: keras>=3.0.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (3.1.1)
    Requirement already satisfied: tensorflow-io-gcs-filesystem>=0.23.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (0.31.0)
    Requirement already satisfied: numpy<2.0.0,>=1.23.5 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.26.4)
    Requirement already satisfied: wheel<1.0,>=0.23.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from astunparse>=1.6.0->tensorflow-intel==2.16.1->tensorflow) (0.43.0)
    Requirement already satisfied: rich in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from keras>=3.0.0->tensorflow-intel==2.16.1->tensorflow) (13.7.1)
    Requirement already satisfied: namex in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from keras>=3.0.0->tensorflow-intel==2.16.1->tensorflow) (0.0.7)
    Requirement already satisfied: optree in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from keras>=3.0.0->tensorflow-intel==2.16.1->tensorflow) (0.11.0)
    Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (3.3.2)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (3.6)
    Requirement already satisfied: urllib3<3,>=1.21.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (2.2.1)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (2024.2.2)
    Requirement already satisfied: markdown>=2.6.8 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (3.6)
    Requirement already satisfied: tensorboard-data-server<0.8.0,>=0.7.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (0.7.2)
    Requirement already satisfied: werkzeug>=1.0.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (3.0.1)
    Requirement already satisfied: MarkupSafe>=2.1.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from werkzeug>=1.0.1->tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (2.1.5)
    Requirement already satisfied: markdown-it-py>=2.2.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from rich->keras>=3.0.0->tensorflow-intel==2.16.1->tensorflow) (3.0.0)
    Requirement already satisfied: pygments<3.0.0,>=2.13.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from rich->keras>=3.0.0->tensorflow-intel==2.16.1->tensorflow) (2.17.2)
    Requirement already satisfied: mdurl~=0.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from markdown-it-py>=2.2.0->rich->keras>=3.0.0->tensorflow-intel==2.16.1->tensorflow) (0.1.2)
    Requirement already satisfied: pandas in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (2.2.1)
    Requirement already satisfied: numpy<2,>=1.22.4 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: six>=1.5 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Requirement already satisfied: seaborn in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (0.13.2)
    Requirement already satisfied: numpy!=1.24.0,>=1.20 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from seaborn) (1.26.4)
    Requirement already satisfied: pandas>=1.2 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from seaborn) (2.2.1)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.4 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from seaborn) (3.8.3)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (4.50.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.4.5)
    Requirement already satisfied: packaging>=20.0 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (24.0)
    Requirement already satisfied: pillow>=8 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (10.2.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: six>=1.5 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from python-dateutil>=2.7->matplotlib!=3.6.1,>=3.4->seaborn) (1.16.0)
    


```python
import tensorflow as tf
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
```

## Data Preprocessing

### Training Image Preprocessing


```python
training_set = tf.keras.utils.image_dataset_from_directory(
    'train',
    labels="inferred",
    label_mode="categorical",
    class_names=None,
    color_mode="rgb",
    batch_size=32,
    image_size=(128, 128),
    shuffle=True,
    seed=None,
    validation_split=None,
    subset=None,
    interpolation="bilinear",
    follow_links=False,
    crop_to_aspect_ratio=False,
#     pad_to_aspect_ratio=False,
#     data_format=None,
#     verbose=True,
)
```

    Found 70295 files belonging to 38 classes.
    

### Validation Image Preprocessing


```python
validation_set = tf.keras.utils.image_dataset_from_directory(
    'valid',
    labels="inferred",
    label_mode="categorical",
    class_names=None,
    color_mode="rgb",
    batch_size=32,
    image_size=(128, 128),
    shuffle=True,
    seed=None,
    validation_split=None,
    subset=None,
    interpolation="bilinear",
    follow_links=False,
    crop_to_aspect_ratio=False,
#     pad_to_aspect_ratio=False,
#     data_format=None,
#     verbose=True,
)
```

    Found 17572 files belonging to 38 classes.
    


```python
training_set
```




    <_PrefetchDataset element_spec=(TensorSpec(shape=(None, 128, 128, 3), dtype=tf.float32, name=None), TensorSpec(shape=(None, 38), dtype=tf.float32, name=None))>




```python
for x,y in training_set:
    print(x)
    print(y)
    break
```

    tf.Tensor(
    [[[[ 79.75  68.25  76.25]
       [146.25 131.   137.75]
       [147.   128.75 132.  ]
       ...
       [174.5  162.5  162.5 ]
       [172.   160.   160.  ]
       [176.   164.   164.  ]]
    
      [[ 72.25  60.75  66.25]
       [136.   121.25 124.  ]
       [150.75 134.5  134.  ]
       ...
       [174.5  162.5  162.5 ]
       [160.   148.   148.  ]
       [179.5  167.5  167.5 ]]
    
      [[ 76.25  67.    67.25]
       [152.75 140.75 139.  ]
       [138.   123.75 116.  ]
       ...
       [183.5  171.5  171.5 ]
       [175.   163.   163.  ]
       [167.   155.   155.  ]]
    
      ...
    
      [[ 70.5   60.5   63.5 ]
       [140.75 129.75 133.75]
       [152.   141.   145.  ]
       ...
       [163.75 152.75 156.75]
       [170.5  159.5  163.5 ]
       [166.   155.   159.  ]]
    
      [[ 81.75  71.75  74.75]
       [140.25 129.25 133.25]
       [147.   136.   140.  ]
       ...
       [158.25 147.25 151.25]
       [174.   163.   167.  ]
       [172.75 161.75 165.75]]
    
      [[ 74.    64.    67.  ]
       [140.   129.   133.  ]
       [142.25 131.25 135.25]
       ...
       [170.75 159.75 163.75]
       [163.   152.   156.  ]
       [163.5  152.5  156.5 ]]]
    
    
     [[[156.   151.5  162.  ]
       [153.5  151.   165.  ]
       [146.   146.   164.  ]
       ...
       [ 90.25  83.25  99.25]
       [ 92.75  85.75 101.75]
       [ 94.25  87.25 103.25]]
    
      [[158.75 154.25 165.75]
       [152.   149.25 163.5 ]
       [150.5  150.5  168.5 ]
       ...
       [ 86.75  79.75  95.75]
       [ 87.25  80.25  96.25]
       [ 87.75  80.75  96.75]]
    
      [[162.   157.5  169.  ]
       [155.5  153.   167.25]
       [154.75 153.75 171.25]
       ...
       [ 88.5   81.5   97.5 ]
       [ 89.5   82.5   98.5 ]
       [ 89.75  82.75  98.75]]
    
      ...
    
      [[168.75 161.75 168.75]
       [169.   162.   169.  ]
       [170.   163.   170.  ]
       ...
       [153.25 148.25 154.25]
       [154.25 149.25 155.25]
       [157.   152.   158.  ]]
    
      [[167.5  160.5  167.5 ]
       [169.75 162.75 169.75]
       [168.25 161.25 168.25]
       ...
       [154.5  149.5  155.5 ]
       [155.   150.   156.  ]
       [155.75 150.75 156.75]]
    
      [[166.   159.   166.  ]
       [169.5  162.5  169.5 ]
       [166.   159.   166.  ]
       ...
       [156.25 151.25 157.25]
       [157.5  152.5  158.5 ]
       [156.75 151.75 157.75]]]
    
    
     [[[245.25 237.25 234.25]
       [244.25 236.25 233.25]
       [250.75 242.75 239.75]
       ...
       [224.75 213.75 209.75]
       [232.5  221.5  217.5 ]
       [235.75 224.75 220.75]]
    
      [[250.   242.   239.  ]
       [244.   236.   233.  ]
       [245.25 237.25 234.25]
       ...
       [234.25 223.25 219.25]
       [234.5  223.5  219.5 ]
       [232.25 221.25 217.25]]
    
      [[247.25 239.25 236.25]
       [248.75 240.75 237.75]
       [247.25 239.25 236.25]
       ...
       [231.   220.   216.  ]
       [229.5  218.5  214.5 ]
       [233.   222.   218.  ]]
    
      ...
    
      [[242.   233.   228.  ]
       [245.75 237.25 232.25]
       [237.25 228.25 223.25]
       ...
       [200.5  182.5  178.5 ]
       [213.   195.   191.  ]
       [236.   218.   214.  ]]
    
      [[247.5  239.75 234.75]
       [236.5  227.5  222.5 ]
       [247.75 238.75 233.75]
       ...
       [207.25 189.25 185.25]
       [210.   192.   188.  ]
       [220.75 202.75 198.75]]
    
      [[239.5  230.5  225.5 ]
       [244.25 235.25 230.25]
       [238.5  229.5  224.5 ]
       ...
       [215.75 197.75 193.75]
       [215.75 197.75 193.75]
       [234.75 217.   213.  ]]]
    
    
     ...
    
    
     [[[153.   143.   141.  ]
       [158.5  148.5  146.5 ]
       [157.5  147.5  145.5 ]
       ...
       [133.5  122.5  120.5 ]
       [128.   117.   115.  ]
       [142.75 131.75 129.75]]
    
      [[159.25 149.25 147.25]
       [158.25 148.25 146.25]
       [165.75 155.75 153.75]
       ...
       [148.   137.   135.  ]
       [147.25 136.25 134.25]
       [146.   135.   133.  ]]
    
      [[162.25 152.25 150.25]
       [167.   157.   155.  ]
       [154.25 144.25 142.25]
       ...
       [152.25 141.25 139.25]
       [138.   127.   125.  ]
       [143.   132.   130.  ]]
    
      ...
    
      [[188.75 184.75 185.75]
       [194.   190.   191.  ]
       [193.25 189.25 190.25]
       ...
       [171.5  167.5  168.5 ]
       [181.5  177.5  178.5 ]
       [181.   177.   178.  ]]
    
      [[187.   183.   184.  ]
       [187.   183.   184.  ]
       [183.   179.   180.  ]
       ...
       [168.5  164.5  165.5 ]
       [170.75 166.75 167.75]
       [172.75 168.75 169.75]]
    
      [[187.   183.   184.  ]
       [193.5  189.5  190.5 ]
       [191.25 187.25 188.25]
       ...
       [175.5  171.5  172.5 ]
       [188.75 184.75 185.75]
       [177.   173.   174.  ]]]
    
    
     [[[147.   136.   144.  ]
       [150.   139.   147.  ]
       [149.75 138.75 146.75]
       ...
       [132.75 112.75 121.75]
       [133.75 113.75 122.75]
       [145.25 125.25 134.25]]
    
      [[155.75 144.75 152.75]
       [145.75 134.75 142.75]
       [149.   138.   146.  ]
       ...
       [134.75 114.75 123.75]
       [129.75 109.75 118.75]
       [125.5  105.5  114.5 ]]
    
      [[143.25 132.25 140.25]
       [148.5  137.5  145.5 ]
       [139.25 128.25 136.25]
       ...
       [135.5  118.5  126.5 ]
       [133.5  116.5  124.5 ]
       [123.75 106.75 114.75]]
    
      ...
    
      [[153.75 141.75 153.75]
       [152.75 140.75 152.75]
       [152.25 140.25 152.25]
       ...
       [111.25  99.25 109.25]
       [111.    99.   109.  ]
       [115.5  103.5  113.5 ]]
    
      [[149.5  137.5  149.5 ]
       [148.5  136.5  148.5 ]
       [149.25 137.25 149.25]
       ...
       [117.   105.   115.  ]
       [120.75 108.75 118.75]
       [116.5  104.5  114.5 ]]
    
      [[148.   136.   148.  ]
       [145.5  133.5  145.5 ]
       [146.25 134.25 146.25]
       ...
       [112.75 100.75 110.75]
       [117.   105.   115.  ]
       [113.   101.   111.  ]]]
    
    
     [[[185.5  182.5  177.5 ]
       [186.75 183.75 178.75]
       [187.5  184.5  179.5 ]
       ...
       [150.   147.   140.  ]
       [150.75 147.75 140.75]
       [147.5  144.5  137.5 ]]
    
      [[185.75 182.75 177.75]
       [187.75 184.75 179.75]
       [188.75 185.75 180.75]
       ...
       [147.25 144.25 137.25]
       [145.25 142.25 135.25]
       [148.   145.   138.  ]]
    
      [[186.5  183.5  178.5 ]
       [188.75 185.75 180.75]
       [191.   188.   183.  ]
       ...
       [146.75 143.75 136.75]
       [145.75 142.75 135.75]
       [138.   135.   128.  ]]
    
      ...
    
      [[123.25 119.25 110.25]
       [117.25 113.25 104.25]
       [111.75 107.75  98.75]
       ...
       [108.25 102.25  90.25]
       [108.25 102.25  90.25]
       [117.   111.    99.  ]]
    
      [[108.   104.    95.  ]
       [113.5  109.5  100.5 ]
       [115.5  111.5  102.5 ]
       ...
       [104.25  98.25  86.25]
       [108.75 102.75  90.75]
       [111.5  105.5   93.5 ]]
    
      [[112.25 108.25  99.25]
       [109.25 105.25  96.25]
       [107.5  103.5   94.5 ]
       ...
       [103.    97.    85.  ]
       [105.75  99.75  87.75]
       [104.5   98.5   86.5 ]]]], shape=(32, 128, 128, 3), dtype=float32)
    tf.Tensor(
    [[0. 1. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     ...
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]], shape=(32, 38), dtype=float32)
    


```python
for x,y in training_set:
    print(x,x.shape)
    print(y,y.shape)
    break
```

    tf.Tensor(
    [[[[225.5  211.5  210.5 ]
       [225.75 211.75 210.75]
       [226.   212.   211.  ]
       ...
       [228.25 214.25 213.25]
       [225.25 211.25 210.25]
       [221.25 207.25 206.25]]
    
      [[235.75 221.75 220.75]
       [228.75 214.75 213.75]
       [225.75 211.75 210.75]
       ...
       [236.25 222.25 221.25]
       [231.   217.   216.  ]
       [228.   214.25 213.25]]
    
      [[234.   220.   219.  ]
       [241.   227.   226.  ]
       [229.25 215.25 214.25]
       ...
       [225.75 211.75 210.75]
       [227.5  213.5  212.5 ]
       [227.25 213.25 212.25]]
    
      ...
    
      [[219.   205.   202.  ]
       [218.5  204.5  201.5 ]
       [225.75 211.75 208.75]
       ...
       [234.25 220.25 217.25]
       [227.25 213.25 210.25]
       [234.25 220.25 217.25]]
    
      [[233.25 220.75 217.75]
       [225.75 211.75 208.75]
       [215.25 201.25 198.25]
       ...
       [232.25 220.75 217.75]
       [236.25 222.25 219.25]
       [219.75 205.75 202.75]]
    
      [[231.   217.   214.  ]
       [218.5  204.5  201.5 ]
       [229.   215.   212.  ]
       ...
       [230.5  216.5  213.5 ]
       [227.25 213.25 210.25]
       [229.   215.   212.  ]]]
    
    
     [[[  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       ...
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]]
    
      [[  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       ...
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]]
    
      [[  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       ...
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]]
    
      ...
    
      [[  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       ...
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]]
    
      [[  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       ...
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]]
    
      [[  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       ...
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]
       [  0.     0.     0.  ]]]
    
    
     [[[150.5  142.5  153.5 ]
       [131.75 123.75 134.75]
       [127.75 119.75 130.75]
       ...
       [162.25 154.25 165.25]
       [166.   158.   169.  ]
       [158.75 150.75 161.75]]
    
      [[140.25 132.25 143.25]
       [125.25 117.25 128.25]
       [137.5  129.5  140.5 ]
       ...
       [160.   152.   163.  ]
       [153.5  145.5  156.5 ]
       [159.25 151.25 162.25]]
    
      [[145.25 137.25 148.25]
       [160.75 152.75 163.75]
       [142.   134.   145.  ]
       ...
       [150.75 142.75 153.75]
       [156.25 148.25 159.25]
       [157.   149.   160.  ]]
    
      ...
    
      [[186.25 181.25 188.25]
       [172.5  167.5  174.5 ]
       [174.25 169.25 176.25]
       ...
       [182.   176.   186.  ]
       [177.75 171.75 181.75]
       [174.5  168.5  178.5 ]]
    
      [[170.25 165.25 172.25]
       [171.75 166.75 173.75]
       [191.5  186.5  193.5 ]
       ...
       [173.   167.   177.  ]
       [172.25 166.25 176.25]
       [180.5  174.5  184.5 ]]
    
      [[167.   162.   169.  ]
       [174.25 169.25 176.25]
       [179.75 174.75 181.75]
       ...
       [175.25 169.25 179.25]
       [173.25 167.25 177.25]
       [175.75 169.75 179.75]]]
    
    
     ...
    
    
     [[[144.75 139.75 135.75]
       [141.25 136.25 132.25]
       [153.75 148.75 144.75]
       ...
       [173.25 171.25 172.25]
       [175.75 173.75 174.75]
       [176.25 174.25 175.25]]
    
      [[153.75 148.75 144.75]
       [147.5  142.5  138.5 ]
       [149.5  144.5  140.5 ]
       ...
       [167.75 165.75 166.75]
       [167.75 165.75 166.75]
       [170.5  168.5  169.5 ]]
    
      [[150.25 145.25 141.25]
       [137.25 132.25 128.25]
       [131.75 126.75 122.75]
       ...
       [171.75 169.75 170.75]
       [175.25 173.25 174.25]
       [174.75 172.75 173.75]]
    
      ...
    
      [[109.75 100.75  95.75]
       [111.25 102.25  97.25]
       [112.5  103.5   98.5 ]
       ...
       [148.5  143.5  139.5 ]
       [155.   150.   146.  ]
       [159.   154.   150.  ]]
    
      [[109.25 100.25  95.25]
       [110.25 101.25  96.25]
       [110.5  101.5   96.5 ]
       ...
       [151.75 146.75 142.75]
       [150.25 145.25 141.25]
       [152.75 147.75 143.75]]
    
      [[118.   109.   104.  ]
       [112.75 103.75  98.75]
       [109.   100.    95.  ]
       ...
       [150.5  145.5  141.5 ]
       [147.   142.   138.  ]
       [147.5  142.5  138.5 ]]]
    
    
     [[[124.75 116.75 114.75]
       [124.75 116.75 114.75]
       [121.75 113.75 111.75]
       ...
       [118.75 108.75 107.75]
       [119.   109.   108.  ]
       [120.5  110.5  109.5 ]]
    
      [[132.5  124.5  122.5 ]
       [120.75 112.75 110.75]
       [126.   118.   116.  ]
       ...
       [115.75 105.75 104.75]
       [114.   104.   103.  ]
       [116.25 106.25 105.25]]
    
      [[116.25 108.25 106.25]
       [123.25 115.25 113.25]
       [124.5  116.5  114.5 ]
       ...
       [124.   114.   113.  ]
       [119.5  109.5  108.5 ]
       [116.25 106.25 105.25]]
    
      ...
    
      [[158.5  154.5  155.5 ]
       [155.25 151.25 152.25]
       [155.   151.   152.  ]
       ...
       [154.5  149.5  146.5 ]
       [154.5  149.5  146.5 ]
       [155.25 150.25 147.25]]
    
      [[160.   156.   157.  ]
       [156.   152.   153.  ]
       [154.75 150.75 151.75]
       ...
       [154.75 149.75 146.75]
       [156.25 151.25 148.25]
       [157.75 152.75 149.75]]
    
      [[156.   152.   153.  ]
       [156.25 152.25 153.25]
       [156.5  152.5  153.5 ]
       ...
       [154.75 149.75 146.75]
       [152.75 147.75 144.75]
       [148.5  143.5  140.5 ]]]
    
    
     [[[155.   147.   158.  ]
       [153.75 145.75 156.75]
       [151.75 143.75 154.75]
       ...
       [ 76.    76.75  25.5 ]
       [ 92.5   90.25  32.  ]
       [108.   102.    39.75]]
    
      [[153.75 145.75 156.75]
       [152.75 144.75 155.75]
       [154.   146.   157.  ]
       ...
       [ 89.25  96.    47.25]
       [ 91.    96.    41.25]
       [ 91.5   96.    37.5 ]]
    
      [[153.5  145.5  156.5 ]
       [150.   142.   153.  ]
       [149.   141.   152.  ]
       ...
       [ 73.5   90.25  44.75]
       [ 73.    89.75  39.25]
       [ 80.5   96.5   44.5 ]]
    
      ...
    
      [[105.25  97.25 108.25]
       [103.25  95.25 106.25]
       [107.25  99.25 110.25]
       ...
       [ 49.25  66.75  29.  ]
       [ 51.    68.75  31.  ]
       [ 58.5   76.25  38.5 ]]
    
      [[103.25  95.25 106.25]
       [106.5   98.5  109.5 ]
       [102.25  94.25 105.25]
       ...
       [ 36.    50.    13.75]
       [ 50.25  63.25  27.25]
       [ 54.    66.5   30.75]]
    
      [[ 98.75  90.75 101.75]
       [ 94.5   86.5   97.5 ]
       [ 98.75  90.75 101.75]
       ...
       [ 56.25  68.75  32.75]
       [ 48.75  57.25  22.75]
       [ 58.25  66.    31.75]]]], shape=(32, 128, 128, 3), dtype=float32) (32, 128, 128, 3)
    tf.Tensor(
    [[0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     ...
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]], shape=(32, 38), dtype=float32) (32, 38)
    

### To avoid overshooting
1. Choose small learning rate default 0.001 , we are taking 0.0001
2. There may be chance of underfitting, so increase number of neuron
3. Add more Convolution layer to extract more important feature from images, there may be possibility that model unable to capture relevant feature or model is confusing due to lack of feature so feed with more feature

## Building Model


```python
from tensorflow.keras.layers import Dense,Conv2D,MaxPool2D,Flatten, Dropout
from tensorflow.keras.models import Sequential
```


```python
model=Sequential()
```

## Building Convolutional Layer


```python
model.add(Conv2D(filters=32, kernel_size=3, padding='same', activation='relu', input_shape=[128, 128, 3]))
model.add(Conv2D(filters=32,kernel_size=3,activation='relu'))
model.add(MaxPool2D(pool_size=2,strides=2))
```

    C:\Users\gupta\Desktop\plant disease detection\tfenv\lib\site-packages\keras\src\layers\convolutional\base_conv.py:99: UserWarning: Do not pass an `input_shape`/`input_dim` argument to a layer. When using Sequential models, prefer using an `Input(shape)` object as the first layer in the model instead.
      super().__init__(
    


```python
model.add(Conv2D(filters=64,kernel_size=3,padding='same',activation='relu'))
model.add(Conv2D(filters=64,kernel_size=3,activation='relu'))
model.add(MaxPool2D(pool_size=2,strides=2))
```


```python
model.add(Conv2D(filters=128,kernel_size=3,padding='same',activation='relu'))
model.add(Conv2D(filters=128,kernel_size=3,activation='relu'))
model.add(MaxPool2D(pool_size=2,strides=2))
```


```python
model.add(Conv2D(filters=256,kernel_size=3,padding='same',activation='relu'))
model.add(Conv2D(filters=256,kernel_size=3,activation='relu'))
model.add(MaxPool2D(pool_size=2,strides=2))
```


```python
model.add(Conv2D(filters=512,kernel_size=3,padding='same',activation='relu'))
model.add(Conv2D(filters=512,kernel_size=3,activation='relu'))
model.add(MaxPool2D(pool_size=2,strides=2))
```


```python
model.add(Dropout(0.25)) #To avoid overfitting
```


```python
model.add(Flatten())
```


```python
model.add(Dense(units=1500,activation='relu'))
```


```python
model.add(Dropout(0.4))
```


```python
## Output Layer
model.add(Dense(units=38,activation='softmax'))
```

## Compiling Model


```python
model.compile(optimizer=tf.keras.optimizers.Adam(
    learning_rate=0.0001),loss='categorical_crossentropy',metrics=['accuracy'])
```


```python
model.summary()
```


<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold">Model: "sequential"</span>
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace">┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┓
┃<span style="font-weight: bold"> Layer (type)                         </span>┃<span style="font-weight: bold"> Output Shape                </span>┃<span style="font-weight: bold">         Param # </span>┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━┩
│ conv2d (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                      │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>, <span style="color: #00af00; text-decoration-color: #00af00">32</span>)        │             <span style="color: #00af00; text-decoration-color: #00af00">896</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">126</span>, <span style="color: #00af00; text-decoration-color: #00af00">126</span>, <span style="color: #00af00; text-decoration-color: #00af00">32</span>)        │           <span style="color: #00af00; text-decoration-color: #00af00">9,248</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ max_pooling2d (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)         │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">63</span>, <span style="color: #00af00; text-decoration-color: #00af00">63</span>, <span style="color: #00af00; text-decoration-color: #00af00">32</span>)          │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_2 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">63</span>, <span style="color: #00af00; text-decoration-color: #00af00">63</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │          <span style="color: #00af00; text-decoration-color: #00af00">18,496</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_3 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">61</span>, <span style="color: #00af00; text-decoration-color: #00af00">61</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │          <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ max_pooling2d_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">30</span>, <span style="color: #00af00; text-decoration-color: #00af00">30</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_4 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">30</span>, <span style="color: #00af00; text-decoration-color: #00af00">30</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)         │          <span style="color: #00af00; text-decoration-color: #00af00">73,856</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_5 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">28</span>, <span style="color: #00af00; text-decoration-color: #00af00">28</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)         │         <span style="color: #00af00; text-decoration-color: #00af00">147,584</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ max_pooling2d_2 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">14</span>, <span style="color: #00af00; text-decoration-color: #00af00">14</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)         │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_6 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">14</span>, <span style="color: #00af00; text-decoration-color: #00af00">14</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)         │         <span style="color: #00af00; text-decoration-color: #00af00">295,168</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_7 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">12</span>, <span style="color: #00af00; text-decoration-color: #00af00">12</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)         │         <span style="color: #00af00; text-decoration-color: #00af00">590,080</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ max_pooling2d_3 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">6</span>, <span style="color: #00af00; text-decoration-color: #00af00">6</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)           │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_8 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">6</span>, <span style="color: #00af00; text-decoration-color: #00af00">6</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)           │       <span style="color: #00af00; text-decoration-color: #00af00">1,180,160</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2d_9 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">4</span>, <span style="color: #00af00; text-decoration-color: #00af00">4</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)           │       <span style="color: #00af00; text-decoration-color: #00af00">2,359,808</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ max_pooling2d_4 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2</span>, <span style="color: #00af00; text-decoration-color: #00af00">2</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)           │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ dropout (<span style="color: #0087ff; text-decoration-color: #0087ff">Dropout</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2</span>, <span style="color: #00af00; text-decoration-color: #00af00">2</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)           │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ flatten (<span style="color: #0087ff; text-decoration-color: #0087ff">Flatten</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)                │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ dense (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                        │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1500</span>)                │       <span style="color: #00af00; text-decoration-color: #00af00">3,073,500</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ dropout_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dropout</span>)                  │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1500</span>)                │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ dense_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                      │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">38</span>)                  │          <span style="color: #00af00; text-decoration-color: #00af00">57,038</span> │
└──────────────────────────────────────┴─────────────────────────────┴─────────────────┘
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Total params: </span><span style="color: #00af00; text-decoration-color: #00af00">7,842,762</span> (29.92 MB)
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">7,842,762</span> (29.92 MB)
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Non-trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">0</span> (0.00 B)
</pre>



## Model Training


```python
training_history=model.fit(x=training_set,validation_data=validation_set,epochs=10)
```

    Epoch 1/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2537s[0m 1s/step - accuracy: 0.4113 - loss: 2.0918 - val_accuracy: 0.8525 - val_loss: 0.4730
    Epoch 2/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4921s[0m 2s/step - accuracy: 0.8420 - loss: 0.5009 - val_accuracy: 0.9230 - val_loss: 0.2429
    Epoch 3/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2447s[0m 1s/step - accuracy: 0.9105 - loss: 0.2775 - val_accuracy: 0.9383 - val_loss: 0.1906
    Epoch 4/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3893s[0m 2s/step - accuracy: 0.9350 - loss: 0.1960 - val_accuracy: 0.9451 - val_loss: 0.1671
    Epoch 5/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2301s[0m 1s/step - accuracy: 0.9528 - loss: 0.1431 - val_accuracy: 0.9573 - val_loss: 0.1397
    Epoch 6/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2292s[0m 1s/step - accuracy: 0.9627 - loss: 0.1119 - val_accuracy: 0.9642 - val_loss: 0.1125
    Epoch 7/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2272s[0m 1s/step - accuracy: 0.9711 - loss: 0.0880 - val_accuracy: 0.9568 - val_loss: 0.1393
    Epoch 8/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2343s[0m 1s/step - accuracy: 0.9748 - loss: 0.0779 - val_accuracy: 0.9653 - val_loss: 0.1217
    Epoch 9/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2237s[0m 1s/step - accuracy: 0.9771 - loss: 0.0690 - val_accuracy: 0.9706 - val_loss: 0.0947
    Epoch 10/10
    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2353s[0m 1s/step - accuracy: 0.9816 - loss: 0.0581 - val_accuracy: 0.9525 - val_loss: 0.1637
    

## Model Evaluation


```python
#Model Evaluation on Training set
train_loss, train_acc = model.evaluate(training_set)
#Training set Accuracy
print('Training accuracy:', train_acc)
```

    [1m2197/2197[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m719s[0m 327ms/step - accuracy: 0.9815 - loss: 0.0584
    Training accuracy: 0.9813784956932068
    


```python
print(train_loss,train_acc)
```

    0.05601634085178375 0.9813784956932068
    


```python
#Validation set Accuracy
val_loss, val_acc = model.evaluate(validation_set)
print('Validation accuracy:', val_acc)
```

    [1m550/550[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m176s[0m 319ms/step - accuracy: 0.9524 - loss: 0.1655
    Validation accuracy: 0.952481210231781
    

### Saving Model


```python
model.save("trained_model.h5")
model.save('trained_plant_disease_model.keras') #it is used to compress file size
```

    WARNING:absl:You are saving your model as an HDF5 file via `model.save()` or `keras.saving.save_model(model)`. This file format is considered legacy. We recommend using instead the native Keras format, e.g. `model.save('my_model.keras')` or `keras.saving.save_model(model, 'my_model.keras')`. 
    


```python
training_history.history #Return Dictionary of history
```




    {'accuracy': [0.6125613451004028,
      0.8652962446212769,
      0.9173910021781921,
      0.9422718286514282,
      0.9566398859024048,
      0.9648481607437134,
      0.9728999137878418,
      0.9761576056480408,
      0.9793157577514648,
      0.9830998182296753],
     'loss': [1.31917142868042,
      0.4199684262275696,
      0.25422152876853943,
      0.1763271987438202,
      0.132105752825737,
      0.10680293291807175,
      0.08436506986618042,
      0.07233617454767227,
      0.06455418467521667,
      0.054157961159944534],
     'val_accuracy': [0.8525494933128357,
      0.9230024814605713,
      0.9383109211921692,
      0.9450830817222595,
      0.9573184847831726,
      0.9642044305801392,
      0.9568063020706177,
      0.9652856588363647,
      0.9706351161003113,
      0.952481210231781],
     'val_loss': [0.47296813130378723,
      0.24292133748531342,
      0.19062699377536774,
      0.16713154315948486,
      0.1396910697221756,
      0.11251150071620941,
      0.1393156349658966,
      0.12166524678468704,
      0.09469074755907059,
      0.16374102234840393]}




```python
#Recording History in json
import json
with open('training_hist.json','w') as f:
  json.dump(training_history.history,f)
```


```python
print(training_history.history.keys())
```

    dict_keys(['accuracy', 'loss', 'val_accuracy', 'val_loss'])
    

### Accuracy Visualization


```python
epochs = [i for i in range(1,11)]
plt.plot(epochs,training_history.history['accuracy'],color='red',label='Training Accuracy')
plt.plot(epochs,training_history.history['val_accuracy'],color='blue',label='Validation Accuracy')
plt.xlabel('No. of Epochs')
plt.ylabel('Accuracy Result')
plt.title('Visualization of Accuracy Result')
plt.legend()
plt.show()
```


    
![png](output_41_0.png)
    


### Some other metrics for model evaluation


```python
class_name = validation_set.class_names
class_name
```




    ['Apple___Apple_scab',
     'Apple___Black_rot',
     'Apple___Cedar_apple_rust',
     'Apple___healthy',
     'Blueberry___healthy',
     'Cherry_(including_sour)___Powdery_mildew',
     'Cherry_(including_sour)___healthy',
     'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot',
     'Corn_(maize)___Common_rust_',
     'Corn_(maize)___Northern_Leaf_Blight',
     'Corn_(maize)___healthy',
     'Grape___Black_rot',
     'Grape___Esca_(Black_Measles)',
     'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)',
     'Grape___healthy',
     'Orange___Haunglongbing_(Citrus_greening)',
     'Peach___Bacterial_spot',
     'Peach___healthy',
     'Pepper,_bell___Bacterial_spot',
     'Pepper,_bell___healthy',
     'Potato___Early_blight',
     'Potato___Late_blight',
     'Potato___healthy',
     'Raspberry___healthy',
     'Soybean___healthy',
     'Squash___Powdery_mildew',
     'Strawberry___Leaf_scorch',
     'Strawberry___healthy',
     'Tomato___Bacterial_spot',
     'Tomato___Early_blight',
     'Tomato___Late_blight',
     'Tomato___Leaf_Mold',
     'Tomato___Septoria_leaf_spot',
     'Tomato___Spider_mites Two-spotted_spider_mite',
     'Tomato___Target_Spot',
     'Tomato___Tomato_Yellow_Leaf_Curl_Virus',
     'Tomato___Tomato_mosaic_virus',
     'Tomato___healthy']




```python
test_set = tf.keras.utils.image_dataset_from_directory(
    'valid', #not test directory
    labels="inferred",
    label_mode="categorical",
    class_names=None,
    color_mode="rgb",
    batch_size=1,
    image_size=(128, 128),
    shuffle=False, #not true coz it will be passed sequentially 
    seed=None,
    validation_split=None,
    subset=None,
    interpolation="bilinear",
    follow_links=False,
    crop_to_aspect_ratio=False
)
```

    Found 17572 files belonging to 38 classes.
    


```python
y_pred = model.predict(test_set)
y_pred, y_pred.shape
```

    [1m17572/17572[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m521s[0m 30ms/step
    




    (array([[9.99999762e-01, 2.34691072e-07, 3.19311439e-12, ...,
             2.67704432e-17, 2.38235979e-15, 3.23502847e-15],
            [9.99999762e-01, 2.06792038e-07, 2.36440988e-12, ...,
             1.38692712e-16, 3.18356385e-14, 4.53157951e-14],
            [1.00000000e+00, 1.19024290e-09, 1.27916408e-14, ...,
             1.14301859e-19, 4.85212699e-17, 1.36849647e-16],
            ...,
            [7.57148833e-09, 4.39102639e-13, 5.03816711e-10, ...,
             1.47297632e-10, 2.62246058e-10, 9.99999166e-01],
            [2.69355804e-09, 1.51434204e-13, 3.35975164e-10, ...,
             2.37843412e-10, 9.09668937e-11, 9.99999881e-01],
            [3.99693619e-16, 8.81078990e-20, 3.40523762e-16, ...,
             1.01956678e-17, 1.06512765e-16, 1.00000000e+00]], dtype=float32),
     (17572, 38))




```python
predicted_categories = tf.argmax(y_pred, axis=1) #argamx() extract maximum value from above prob arr and return its index
#axis=1 means scan vertically
```


```python
predicted_categories
```




    <tf.Tensor: shape=(17572,), dtype=int64, numpy=array([ 0,  0,  0, ..., 37, 37, 37], dtype=int64)>




```python
true_categories = tf.concat([y for x, y in test_set], axis=0)
```


```python
true_categories
```




    <tf.Tensor: shape=(17572, 38), dtype=float32, numpy=
    array([[1., 0., 0., ..., 0., 0., 0.],
           [1., 0., 0., ..., 0., 0., 0.],
           [1., 0., 0., ..., 0., 0., 0.],
           ...,
           [0., 0., 0., ..., 0., 0., 1.],
           [0., 0., 0., ..., 0., 0., 1.],
           [0., 0., 0., ..., 0., 0., 1.]], dtype=float32)>




```python
Y_true = tf.argmax(true_categories, axis=1)
```


```python
Y_true
```




    <tf.Tensor: shape=(17572,), dtype=int64, numpy=array([ 0,  0,  0, ..., 37, 37, 37], dtype=int64)>




```python
!pip install scikit-learn
from sklearn.metrics import confusion_matrix,classification_report
```

    Collecting scikit-learn
      Downloading scikit_learn-1.4.2-cp310-cp310-win_amd64.whl.metadata (11 kB)
    Requirement already satisfied: numpy>=1.19.5 in c:\users\gupta\desktop\plant disease detection\tfenv\lib\site-packages (from scikit-learn) (1.26.4)
    Collecting scipy>=1.6.0 (from scikit-learn)
      Downloading scipy-1.13.0-cp310-cp310-win_amd64.whl.metadata (60 kB)
         ---------------------------------------- 0.0/60.6 kB ? eta -:--:--
         ---------------------------------------- 60.6/60.6 kB 1.6 MB/s eta 0:00:00
    Collecting joblib>=1.2.0 (from scikit-learn)
      Downloading joblib-1.4.0-py3-none-any.whl.metadata (5.4 kB)
    Collecting threadpoolctl>=2.0.0 (from scikit-learn)
      Downloading threadpoolctl-3.4.0-py3-none-any.whl.metadata (13 kB)
    Downloading scikit_learn-1.4.2-cp310-cp310-win_amd64.whl (10.6 MB)
       ---------------------------------------- 0.0/10.6 MB ? eta -:--:--
       - -------------------------------------- 0.4/10.6 MB 11.6 MB/s eta 0:00:01
       ----- ---------------------------------- 1.5/10.6 MB 18.9 MB/s eta 0:00:01
       ------------- -------------------------- 3.5/10.6 MB 27.8 MB/s eta 0:00:01
       --------------------- ------------------ 5.6/10.6 MB 32.7 MB/s eta 0:00:01
       ----------------------------- ---------- 7.9/10.6 MB 36.1 MB/s eta 0:00:01
       -------------------------------- ------- 8.6/10.6 MB 34.5 MB/s eta 0:00:01
       ---------------------------------- ----- 9.1/10.6 MB 29.0 MB/s eta 0:00:01
       ----------------------------------- ---- 9.4/10.6 MB 26.1 MB/s eta 0:00:01
       ----------------------------------- ---- 9.5/10.6 MB 23.3 MB/s eta 0:00:01
       ------------------------------------- -- 9.9/10.6 MB 21.2 MB/s eta 0:00:01
       ---------------------------------------  10.4/10.6 MB 20.5 MB/s eta 0:00:01
       ---------------------------------------  10.6/10.6 MB 19.3 MB/s eta 0:00:01
       ---------------------------------------- 10.6/10.6 MB 18.2 MB/s eta 0:00:00
    Downloading joblib-1.4.0-py3-none-any.whl (301 kB)
       ---------------------------------------- 0.0/301.2 kB ? eta -:--:--
       --------------------------------------- 301.2/301.2 kB 18.2 MB/s eta 0:00:00
    Downloading scipy-1.13.0-cp310-cp310-win_amd64.whl (46.2 MB)
       ---------------------------------------- 0.0/46.2 MB ? eta -:--:--
       ---------------------------------------- 0.5/46.2 MB 15.5 MB/s eta 0:00:03
        --------------------------------------- 0.7/46.2 MB 7.5 MB/s eta 0:00:07
        --------------------------------------- 1.0/46.2 MB 7.0 MB/s eta 0:00:07
       - -------------------------------------- 1.5/46.2 MB 8.2 MB/s eta 0:00:06
       - -------------------------------------- 1.7/46.2 MB 7.1 MB/s eta 0:00:07
       - -------------------------------------- 1.9/46.2 MB 7.1 MB/s eta 0:00:07
       - -------------------------------------- 2.3/46.2 MB 7.6 MB/s eta 0:00:06
       -- ------------------------------------- 2.6/46.2 MB 7.2 MB/s eta 0:00:07
       -- ------------------------------------- 2.9/46.2 MB 7.2 MB/s eta 0:00:06
       -- ------------------------------------- 3.1/46.2 MB 6.9 MB/s eta 0:00:07
       -- ------------------------------------- 3.2/46.2 MB 6.6 MB/s eta 0:00:07
       -- ------------------------------------- 3.3/46.2 MB 6.1 MB/s eta 0:00:08
       --- ------------------------------------ 3.5/46.2 MB 5.8 MB/s eta 0:00:08
       --- ------------------------------------ 3.6/46.2 MB 5.7 MB/s eta 0:00:08
       --- ------------------------------------ 3.7/46.2 MB 5.5 MB/s eta 0:00:08
       --- ------------------------------------ 3.8/46.2 MB 5.3 MB/s eta 0:00:08
       --- ------------------------------------ 3.9/46.2 MB 5.0 MB/s eta 0:00:09
       --- ------------------------------------ 3.9/46.2 MB 4.7 MB/s eta 0:00:09
       --- ------------------------------------ 4.0/46.2 MB 4.5 MB/s eta 0:00:10
       --- ------------------------------------ 4.0/46.2 MB 4.3 MB/s eta 0:00:10
       --- ------------------------------------ 4.0/46.2 MB 4.1 MB/s eta 0:00:11
       --- ------------------------------------ 4.0/46.2 MB 4.0 MB/s eta 0:00:11
       --- ------------------------------------ 4.1/46.2 MB 3.9 MB/s eta 0:00:11
       --- ------------------------------------ 4.1/46.2 MB 3.7 MB/s eta 0:00:12
       --- ------------------------------------ 4.1/46.2 MB 3.7 MB/s eta 0:00:12
       --- ------------------------------------ 4.1/46.2 MB 3.6 MB/s eta 0:00:12
       --- ------------------------------------ 4.2/46.2 MB 3.4 MB/s eta 0:00:13
       --- ------------------------------------ 4.2/46.2 MB 3.3 MB/s eta 0:00:13
       --- ------------------------------------ 4.2/46.2 MB 3.2 MB/s eta 0:00:14
       --- ------------------------------------ 4.2/46.2 MB 3.0 MB/s eta 0:00:14
       --- ------------------------------------ 4.3/46.2 MB 3.0 MB/s eta 0:00:15
       --- ------------------------------------ 4.3/46.2 MB 2.9 MB/s eta 0:00:15
       --- ------------------------------------ 4.4/46.2 MB 2.9 MB/s eta 0:00:15
       --- ------------------------------------ 4.4/46.2 MB 2.9 MB/s eta 0:00:15
       --- ------------------------------------ 4.5/46.2 MB 2.8 MB/s eta 0:00:16
       --- ------------------------------------ 4.6/46.2 MB 2.7 MB/s eta 0:00:16
       --- ------------------------------------ 4.6/46.2 MB 2.7 MB/s eta 0:00:16
       ---- ----------------------------------- 4.6/46.2 MB 2.6 MB/s eta 0:00:16
       ---- ----------------------------------- 4.7/46.2 MB 2.6 MB/s eta 0:00:17
       ---- ----------------------------------- 4.7/46.2 MB 2.6 MB/s eta 0:00:17
       ---- ----------------------------------- 4.7/46.2 MB 2.6 MB/s eta 0:00:17
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 2.4 MB/s eta 0:00:18
       ---- ----------------------------------- 4.7/46.2 MB 1.7 MB/s eta 0:00:25
       ---- ----------------------------------- 4.7/46.2 MB 1.7 MB/s eta 0:00:25
       ---- ----------------------------------- 4.8/46.2 MB 1.6 MB/s eta 0:00:26
       ---- ----------------------------------- 4.8/46.2 MB 1.6 MB/s eta 0:00:26
       ---- ----------------------------------- 4.8/46.2 MB 1.6 MB/s eta 0:00:26
       ---- ----------------------------------- 4.9/46.2 MB 1.6 MB/s eta 0:00:27
       ---- ----------------------------------- 4.9/46.2 MB 1.6 MB/s eta 0:00:27
       ---- ----------------------------------- 4.9/46.2 MB 1.6 MB/s eta 0:00:27
       ---- ----------------------------------- 5.0/46.2 MB 1.6 MB/s eta 0:00:27
       ---- ----------------------------------- 5.0/46.2 MB 1.5 MB/s eta 0:00:27
       ---- ----------------------------------- 5.1/46.2 MB 1.5 MB/s eta 0:00:27
       ---- ----------------------------------- 5.2/46.2 MB 1.5 MB/s eta 0:00:27
       ---- ----------------------------------- 5.2/46.2 MB 1.5 MB/s eta 0:00:27
       ---- ----------------------------------- 5.3/46.2 MB 1.5 MB/s eta 0:00:27
       ---- ----------------------------------- 5.4/46.2 MB 1.6 MB/s eta 0:00:27
       ---- ----------------------------------- 5.5/46.2 MB 1.6 MB/s eta 0:00:27
       ---- ----------------------------------- 5.6/46.2 MB 1.6 MB/s eta 0:00:26
       ---- ----------------------------------- 5.7/46.2 MB 1.6 MB/s eta 0:00:26
       ----- ---------------------------------- 5.9/46.2 MB 1.6 MB/s eta 0:00:26
       ----- ---------------------------------- 6.1/46.2 MB 1.6 MB/s eta 0:00:25
       ----- ---------------------------------- 6.3/46.2 MB 1.7 MB/s eta 0:00:24
       ----- ---------------------------------- 6.5/46.2 MB 1.7 MB/s eta 0:00:24
       ----- ---------------------------------- 6.7/46.2 MB 1.7 MB/s eta 0:00:23
       ------ --------------------------------- 7.0/46.2 MB 1.8 MB/s eta 0:00:22
       ------ --------------------------------- 7.3/46.2 MB 1.9 MB/s eta 0:00:21
       ------ --------------------------------- 7.7/46.2 MB 1.9 MB/s eta 0:00:20
       ------- -------------------------------- 8.2/46.2 MB 2.0 MB/s eta 0:00:19
       ------- -------------------------------- 8.7/46.2 MB 2.1 MB/s eta 0:00:18
       ------- -------------------------------- 9.2/46.2 MB 2.2 MB/s eta 0:00:17
       -------- ------------------------------- 9.8/46.2 MB 2.3 MB/s eta 0:00:16
       --------- ------------------------------ 10.5/46.2 MB 2.4 MB/s eta 0:00:15
       --------- ------------------------------ 11.2/46.2 MB 2.5 MB/s eta 0:00:15
       ---------- ----------------------------- 12.1/46.2 MB 2.5 MB/s eta 0:00:14
       ----------- ---------------------------- 13.1/46.2 MB 2.6 MB/s eta 0:00:13
       ------------ --------------------------- 14.4/46.2 MB 3.3 MB/s eta 0:00:10
       ------------- -------------------------- 15.6/46.2 MB 10.2 MB/s eta 0:00:03
       -------------- ------------------------- 16.5/46.2 MB 14.2 MB/s eta 0:00:03
       -------------- ------------------------- 16.7/46.2 MB 14.2 MB/s eta 0:00:03
       -------------- ------------------------- 17.2/46.2 MB 14.6 MB/s eta 0:00:02
       --------------- ------------------------ 17.5/46.2 MB 13.9 MB/s eta 0:00:03
       --------------- ------------------------ 17.8/46.2 MB 14.2 MB/s eta 0:00:02
       --------------- ------------------------ 18.1/46.2 MB 13.9 MB/s eta 0:00:03
       --------------- ------------------------ 18.4/46.2 MB 13.6 MB/s eta 0:00:03
       ---------------- ----------------------- 18.7/46.2 MB 13.6 MB/s eta 0:00:03
       ---------------- ----------------------- 19.0/46.2 MB 13.4 MB/s eta 0:00:03
       ---------------- ----------------------- 19.3/46.2 MB 12.6 MB/s eta 0:00:03
       ---------------- ----------------------- 19.6/46.2 MB 12.4 MB/s eta 0:00:03
       ----------------- ---------------------- 19.8/46.2 MB 11.9 MB/s eta 0:00:03
       ----------------- ---------------------- 20.2/46.2 MB 11.7 MB/s eta 0:00:03
       ----------------- ---------------------- 20.5/46.2 MB 11.3 MB/s eta 0:00:03
       ----------------- ---------------------- 20.7/46.2 MB 10.9 MB/s eta 0:00:03
       ------------------ --------------------- 21.0/46.2 MB 10.6 MB/s eta 0:00:03
       ------------------ --------------------- 21.3/46.2 MB 10.2 MB/s eta 0:00:03
       ------------------ --------------------- 21.5/46.2 MB 9.9 MB/s eta 0:00:03
       ------------------ --------------------- 21.8/46.2 MB 9.6 MB/s eta 0:00:03
       ------------------- -------------------- 22.1/46.2 MB 9.4 MB/s eta 0:00:03
       ------------------- -------------------- 22.5/46.2 MB 9.2 MB/s eta 0:00:03
       ------------------- -------------------- 22.8/46.2 MB 9.0 MB/s eta 0:00:03
       ------------------- -------------------- 23.1/46.2 MB 8.6 MB/s eta 0:00:03
       -------------------- ------------------- 23.3/46.2 MB 8.4 MB/s eta 0:00:03
       -------------------- ------------------- 23.5/46.2 MB 8.2 MB/s eta 0:00:03
       -------------------- ------------------- 23.8/46.2 MB 7.9 MB/s eta 0:00:03
       -------------------- ------------------- 24.1/46.2 MB 7.6 MB/s eta 0:00:03
       --------------------- ------------------ 24.3/46.2 MB 7.4 MB/s eta 0:00:03
       --------------------- ------------------ 24.5/46.2 MB 7.3 MB/s eta 0:00:03
       --------------------- ------------------ 24.8/46.2 MB 7.0 MB/s eta 0:00:04
       --------------------- ------------------ 25.0/46.2 MB 6.9 MB/s eta 0:00:04
       --------------------- ------------------ 25.3/46.2 MB 6.7 MB/s eta 0:00:04
       ---------------------- ----------------- 25.6/46.2 MB 6.5 MB/s eta 0:00:04
       ---------------------- ----------------- 25.8/46.2 MB 6.4 MB/s eta 0:00:04
       ---------------------- ----------------- 26.1/46.2 MB 6.2 MB/s eta 0:00:04
       ---------------------- ----------------- 26.4/46.2 MB 6.1 MB/s eta 0:00:04
       ----------------------- ---------------- 26.7/46.2 MB 6.0 MB/s eta 0:00:04
       ----------------------- ---------------- 27.0/46.2 MB 6.1 MB/s eta 0:00:04
       ----------------------- ---------------- 27.3/46.2 MB 6.0 MB/s eta 0:00:04
       ----------------------- ---------------- 27.6/46.2 MB 6.0 MB/s eta 0:00:04
       ------------------------ --------------- 27.9/46.2 MB 6.1 MB/s eta 0:00:04
       ------------------------ --------------- 28.3/46.2 MB 6.1 MB/s eta 0:00:03
       ------------------------ --------------- 28.6/46.2 MB 6.1 MB/s eta 0:00:03
       ------------------------- -------------- 29.0/46.2 MB 6.1 MB/s eta 0:00:03
       ------------------------- -------------- 29.3/46.2 MB 6.2 MB/s eta 0:00:03
       ------------------------- -------------- 29.7/46.2 MB 6.2 MB/s eta 0:00:03
       ------------------------- -------------- 30.0/46.2 MB 6.2 MB/s eta 0:00:03
       -------------------------- ------------- 30.4/46.2 MB 6.2 MB/s eta 0:00:03
       -------------------------- ------------- 30.8/46.2 MB 6.3 MB/s eta 0:00:03
       --------------------------- ------------ 31.2/46.2 MB 6.4 MB/s eta 0:00:03
       --------------------------- ------------ 31.6/46.2 MB 6.5 MB/s eta 0:00:03
       --------------------------- ------------ 31.9/46.2 MB 6.5 MB/s eta 0:00:03
       --------------------------- ------------ 32.2/46.2 MB 6.5 MB/s eta 0:00:03
       ---------------------------- ----------- 32.5/46.2 MB 6.4 MB/s eta 0:00:03
       ---------------------------- ----------- 32.8/46.2 MB 6.4 MB/s eta 0:00:03
       ---------------------------- ----------- 33.0/46.2 MB 6.4 MB/s eta 0:00:03
       ---------------------------- ----------- 33.3/46.2 MB 6.4 MB/s eta 0:00:03
       ----------------------------- ---------- 33.6/46.2 MB 6.4 MB/s eta 0:00:02
       ----------------------------- ---------- 33.9/46.2 MB 6.5 MB/s eta 0:00:02
       ----------------------------- ---------- 34.2/46.2 MB 6.5 MB/s eta 0:00:02
       ----------------------------- ---------- 34.5/46.2 MB 6.5 MB/s eta 0:00:02
       ------------------------------ --------- 34.7/46.2 MB 6.7 MB/s eta 0:00:02
       ------------------------------ --------- 35.1/46.2 MB 6.7 MB/s eta 0:00:02
       ------------------------------ --------- 35.4/46.2 MB 6.8 MB/s eta 0:00:02
       ------------------------------ --------- 35.7/46.2 MB 6.8 MB/s eta 0:00:02
       ------------------------------- -------- 36.1/46.2 MB 6.8 MB/s eta 0:00:02
       ------------------------------- -------- 36.4/46.2 MB 6.9 MB/s eta 0:00:02
       ------------------------------- -------- 36.6/46.2 MB 7.0 MB/s eta 0:00:02
       -------------------------------- ------- 37.0/46.2 MB 6.9 MB/s eta 0:00:02
       -------------------------------- ------- 37.2/46.2 MB 6.9 MB/s eta 0:00:02
       -------------------------------- ------- 37.5/46.2 MB 6.8 MB/s eta 0:00:02
       -------------------------------- ------- 37.7/46.2 MB 6.8 MB/s eta 0:00:02
       -------------------------------- ------- 38.0/46.2 MB 6.8 MB/s eta 0:00:02
       --------------------------------- ------ 38.2/46.2 MB 6.7 MB/s eta 0:00:02
       --------------------------------- ------ 38.5/46.2 MB 6.7 MB/s eta 0:00:02
       --------------------------------- ------ 38.7/46.2 MB 6.6 MB/s eta 0:00:02
       --------------------------------- ------ 39.0/46.2 MB 6.6 MB/s eta 0:00:02
       ---------------------------------- ----- 39.3/46.2 MB 6.5 MB/s eta 0:00:02
       ---------------------------------- ----- 39.6/46.2 MB 6.5 MB/s eta 0:00:02
       ---------------------------------- ----- 39.9/46.2 MB 6.5 MB/s eta 0:00:01
       ---------------------------------- ----- 40.2/46.2 MB 6.4 MB/s eta 0:00:01
       ----------------------------------- ---- 40.5/46.2 MB 6.4 MB/s eta 0:00:01
       ----------------------------------- ---- 40.8/46.2 MB 6.4 MB/s eta 0:00:01
       ----------------------------------- ---- 41.1/46.2 MB 6.3 MB/s eta 0:00:01
       ----------------------------------- ---- 41.4/46.2 MB 6.3 MB/s eta 0:00:01
       ------------------------------------ --- 41.7/46.2 MB 6.2 MB/s eta 0:00:01
       ------------------------------------ --- 42.1/46.2 MB 6.4 MB/s eta 0:00:01
       ------------------------------------ --- 42.4/46.2 MB 6.3 MB/s eta 0:00:01
       ------------------------------------- -- 42.8/46.2 MB 6.4 MB/s eta 0:00:01
       ------------------------------------- -- 43.1/46.2 MB 6.4 MB/s eta 0:00:01
       ------------------------------------- -- 43.5/46.2 MB 6.4 MB/s eta 0:00:01
       ------------------------------------- -- 43.8/46.2 MB 6.5 MB/s eta 0:00:01
       -------------------------------------- - 44.2/46.2 MB 6.6 MB/s eta 0:00:01
       -------------------------------------- - 44.5/46.2 MB 6.6 MB/s eta 0:00:01
       -------------------------------------- - 44.7/46.2 MB 6.5 MB/s eta 0:00:01
       -------------------------------------- - 45.0/46.2 MB 6.5 MB/s eta 0:00:01
       ---------------------------------------  45.3/46.2 MB 6.5 MB/s eta 0:00:01
       ---------------------------------------  45.5/46.2 MB 6.5 MB/s eta 0:00:01
       ---------------------------------------  45.8/46.2 MB 6.5 MB/s eta 0:00:01
       ---------------------------------------  46.1/46.2 MB 6.4 MB/s eta 0:00:01
       ---------------------------------------  46.2/46.2 MB 6.4 MB/s eta 0:00:01
       ---------------------------------------  46.2/46.2 MB 6.4 MB/s eta 0:00:01
       ---------------------------------------  46.2/46.2 MB 6.4 MB/s eta 0:00:01
       ---------------------------------------  46.2/46.2 MB 6.4 MB/s eta 0:00:01
       ---------------------------------------- 46.2/46.2 MB 5.8 MB/s eta 0:00:00
    Downloading threadpoolctl-3.4.0-py3-none-any.whl (17 kB)
    Installing collected packages: threadpoolctl, scipy, joblib, scikit-learn
    Successfully installed joblib-1.4.0 scikit-learn-1.4.2 scipy-1.13.0 threadpoolctl-3.4.0
    


```python
# Precision Recall Fscore
print(classification_report(Y_true,predicted_categories,target_names=class_name))
```

                                                        precision    recall  f1-score   support
    
                                    Apple___Apple_scab       0.89      0.97      0.93       504
                                     Apple___Black_rot       0.98      0.98      0.98       497
                              Apple___Cedar_apple_rust       0.96      0.98      0.97       440
                                       Apple___healthy       0.97      0.90      0.93       502
                                   Blueberry___healthy       0.95      0.99      0.97       454
              Cherry_(including_sour)___Powdery_mildew       0.99      0.97      0.98       421
                     Cherry_(including_sour)___healthy       0.99      0.98      0.98       456
    Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot       0.96      0.89      0.92       410
                           Corn_(maize)___Common_rust_       0.99      0.99      0.99       477
                   Corn_(maize)___Northern_Leaf_Blight       0.93      0.97      0.95       477
                                Corn_(maize)___healthy       0.99      1.00      0.99       465
                                     Grape___Black_rot       0.95      1.00      0.97       472
                          Grape___Esca_(Black_Measles)       1.00      0.95      0.97       480
            Grape___Leaf_blight_(Isariopsis_Leaf_Spot)       1.00      1.00      1.00       430
                                       Grape___healthy       0.98      1.00      0.99       423
              Orange___Haunglongbing_(Citrus_greening)       0.99      0.98      0.99       503
                                Peach___Bacterial_spot       0.96      0.95      0.96       459
                                       Peach___healthy       0.97      1.00      0.99       432
                         Pepper,_bell___Bacterial_spot       0.91      0.99      0.95       478
                                Pepper,_bell___healthy       0.88      0.96      0.92       497
                                 Potato___Early_blight       0.98      0.94      0.96       485
                                  Potato___Late_blight       0.95      0.94      0.95       485
                                      Potato___healthy       0.98      0.92      0.95       456
                                   Raspberry___healthy       1.00      0.88      0.94       445
                                     Soybean___healthy       0.99      0.94      0.97       505
                               Squash___Powdery_mildew       0.99      0.97      0.98       434
                              Strawberry___Leaf_scorch       1.00      0.95      0.97       444
                                  Strawberry___healthy       0.97      0.98      0.98       456
                               Tomato___Bacterial_spot       0.99      0.95      0.97       425
                                 Tomato___Early_blight       0.96      0.84      0.89       480
                                  Tomato___Late_blight       0.89      0.92      0.91       463
                                    Tomato___Leaf_Mold       0.93      0.98      0.96       470
                           Tomato___Septoria_leaf_spot       0.79      0.93      0.85       436
         Tomato___Spider_mites Two-spotted_spider_mite       0.95      0.92      0.93       435
                                  Tomato___Target_Spot       0.93      0.72      0.81       457
                Tomato___Tomato_Yellow_Leaf_Curl_Virus       0.98      0.99      0.98       490
                          Tomato___Tomato_mosaic_virus       0.97      0.96      0.96       448
                                      Tomato___healthy       0.82      1.00      0.90       481
    
                                              accuracy                           0.95     17572
                                             macro avg       0.96      0.95      0.95     17572
                                          weighted avg       0.95      0.95      0.95     17572
    
    


```python
cm = confusion_matrix(Y_true,predicted_categories)
#cm.shape
cm
```




    array([[489,   5,   0, ...,   0,   0,   0],
           [  1, 489,   0, ...,   0,   0,   0],
           [  0,   0, 432, ...,   0,   0,   2],
           ...,
           [  0,   0,   2, ..., 483,   0,   0],
           [  0,   0,   0, ...,   0, 428,   3],
           [  0,   0,   0, ...,   0,   0, 481]], dtype=int64)



### Confusion Matrix Visualization


```python
#sns.heatmap(cm)
```


```python
plt.figure(figsize=(40, 40))
sns.heatmap(cm,annot=True,annot_kws={"size": 20})

plt.xlabel('Predicted Class',fontsize = 30)
plt.ylabel('Actual Class',fontsize = 30)
plt.title('Plant Disease Prediction Confusion Matrix',fontsize = 40)
plt.show()
```


    
![png](output_57_0.png)
    



```python

```


```python

```
